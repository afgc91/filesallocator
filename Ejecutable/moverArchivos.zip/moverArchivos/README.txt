1. Descomprimir.
2. Ejecutar.
3. Elegir archivo que contiene los directorios donde est�n los archivos a mover.
4. Elegir el archivo que contiene los directorios donde deben quedar movidos los archivos.
5. Ingresar la cantidad de archivos que debe haber por folder.
6. Click en aceptar.